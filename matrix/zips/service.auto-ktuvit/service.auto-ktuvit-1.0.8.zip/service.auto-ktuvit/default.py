#!/usr/bin/python
from resources.lib.sub_service import *

monitor = xbmc.Monitor()

log("AutoKtuvit initialized")
player = AutoKtuvitPlayer()

while not monitor.abortRequested():
    monitor.waitForAbort(1)

del player
