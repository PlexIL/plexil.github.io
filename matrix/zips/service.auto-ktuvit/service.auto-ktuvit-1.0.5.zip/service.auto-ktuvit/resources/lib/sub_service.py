from resources.lib.KtuvitUtils import *
# import web_pdb

__addon__ = xbmcaddon.Addon()
__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__temp__ = xbmcvfs.translatePath(os.path.join(__profile__, 'temp', ''))

__ktuvit_addon__ = xbmcaddon.Addon('service.subtitles.ktuvit')
username = __ktuvit_addon__.getSetting("username")
password = __ktuvit_addon__.getSetting("password")
autopause = True if __addon__.getSetting("autopause") else False

helper = None
if username and password:
    helper = Ktuvit(username, password)


class AutoKtuvitPlayer(xbmc.Player):
    def __init__(self, *args, **kwargs):
        xbmc.Player.__init__(self)

    def onAVStarted(self) -> None:
        log("onAVStarted triggered")
        if not helper:
            xbmcgui.Dialog().notification(
                "Enter Ktuvit credentials",
                "Set username and password",
                xbmcgui.NOTIFICATION_ERROR,
                5000)
            return None

        if not self.isPlayingVideo():
            return None

        if 'heb' in self.getAvailableSubtitleStreams():
            xbmcgui.Dialog().notification(
                "Subtitles Present",
                "Hebrew subtitles already present",
                xbmcgui.NOTIFICATION_INFO,
                5000)
            return None

        if xbmcvfs.exists(__temp__):
            (dirs, files) = xbmcvfs.listdir(__temp__)
            for file in files:
                xbmcvfs.delete(os.path.join(__temp__, file))
        else:
            xbmcvfs.mkdirs(__temp__)
        # Get the filename of the currently playing video
        # player = xbmc.Player()
        # filename = player.getPlayingFile()

        item = {
            'year': xbmc.getInfoLabel("VideoPlayer.Year"),
            'season': str(xbmc.getInfoLabel("VideoPlayer.Season")),
            'episode': str(xbmc.getInfoLabel("VideoPlayer.Episode")),
            'tvshow': normalizeString(xbmc.getInfoLabel("VideoPlayer.TVshowtitle")),
            'title': normalizeString(xbmc.getInfoLabel("VideoPlayer.OriginalTitle"))
        }
        log(item)

        if item['title'] == "":
            item['title'] = normalizeString(xbmc.getInfoLabel("VideoPlayer.Title"))

        clean_title(item)
        parse_rls_title(item)
        log("Searching for subtitles")
        if autopause:
            xbmcgui.Dialog().notification(
                f"Pausing video...",
                "Searching for subtitles",
                xbmcgui.NOTIFICATION_INFO)
            self.pause()
        else:
            xbmcgui.Dialog().notification(
                f"Searching subtitles...",
                "Searching for subtitles",
                xbmcgui.NOTIFICATION_INFO)
        subtitles_list = helper.query(item)
        if not subtitles_list:
            log("Subtitles not found")
            xbmcgui.Dialog().notification(
                "Not Found",
                "Subtitle not found!",
                xbmcgui.NOTIFICATION_WARNING,
                5000)
            return None

        log("Subtitles found")
        highest_rating = max(
            subtitles_list,
            key=lambda i: rate_subtitle(i.get('release', ''), item.get('title', '')))

        log(f"highest rating: [{highest_rating.get('subtitle_id')}] - {highest_rating.get('release')}")

        # Download the best subtitle for the video
        rtl = True if __ktuvit_addon__.getSetting('rtl') == "true" else False
        subtitle_file = helper.download_subtitle(highest_rating.get("series_id"), highest_rating.get("subtitle_id"), rtl)
        xbmcgui.Dialog().notification(
            "Resuming video...",
            f"Downloaded subtitles! - {highest_rating.get('release')}",
            xbmcgui.NOTIFICATION_INFO)

        if bool(xbmc.getCondVisibility("Player.Paused") and autopause):
            # Works as a toggle to pause and resume
            self.pause()

        log(f"setting subtitles: {subtitle_file}")
        # Set the subtitle in the Kodi player
        self.setSubtitles(subtitle_file)

