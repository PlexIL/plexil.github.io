import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import unicodedata
import re
from guessit import guessit

__author__ = "PlexIL"

__addon__ = xbmcaddon.Addon()
__scriptid__ = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__language__ = __addon__.getLocalizedString

RTL_FIXER = re.compile(r"(?u)(^(<\w>)*([\s.!?:,'-]*)(.+?)(\s*)(-?\s*)$)", re.UNICODE)
regex_nonchar = re.compile(r'\W+', re.UNICODE)


def normalizeString(str):
    return unicodedata.normalize('NFKD', str)


def log(msg):
    xbmc.log((u"### [%s] - %s" % (__scriptname__, msg)), level=xbmc.LOGDEBUG)


def notify(msg_id):
    xbmcgui.Dialog().notification(__scriptname__, __language__(msg_id))


def rate_subtitle(subtitle_filename, video_filename):

    subtitle_info = guessit(subtitle_filename)
    video_info = guessit(video_filename)

    common_keys = set(subtitle_info.keys()) & set(video_info.keys())
    common_elements = {key: subtitle_info[key] for key in common_keys if subtitle_info[key] == video_info[key]}
    return len(common_elements)


def clean_title(item):
    title = os.path.splitext(os.path.basename(item["title"]))[0]
    tvshow = os.path.splitext(os.path.basename(item["tvshow"]))[0]

    item["title"] = title.strip()
    item["tvshow"] = tvshow.strip()

    # Removes country identifier at the end
    item["title"] = re.sub(r'\([^\)]+\)$', '', item["title"]).strip()
    item["tvshow"] = re.sub(r'\([^\)]+\)$', '', item["tvshow"]).strip()


def parse_rls_title(item):
    title = regex_nonchar.sub(' ', item.get("title", ""))
    tvshow = regex_nonchar.sub(' ', item.get("tvshow", ""))
    groups = re.findall(
        r"(.*?) (\d{4})? ?(?:s|season|)(\d{1,2})(?:e|episode|x|\n)(\d{1,2})",
        title + " " + tvshow,
        re.I)

    if groups:
        title, year, season, episode = groups[0]
        item["year"] = str(int(year)) if year and len(year) == 4 else year

        item["tvshow"] = regex_nonchar.sub(' ', title).strip()
        item["season"] = str(int(season))
        item["episode"] = str(int(episode))
        log("TV Parsed Item: %s" % (item,))


def fix_rtl_punctuation(content):
    result = []
    for line in content.splitlines():
        result.append(RTL_FIXER.sub(r"\2\6\5\4\3", line))
    return "\n".join(result)


def search(helper, item):
    subtitles_list = helper.query(item)
    if not subtitles_list:
        return None

    list_items = []
    for it in subtitles_list:
        subtitle_row = xbmcgui.ListItem(
            label=xbmc.convertLanguage(it["language"], xbmc.ENGLISH_NAME), label2=it["release"])

        # listitem.setArt({'icon': '5', 'thumb': it["language"]})
        subtitle_row.setArt({'thumb': it["language"]})

        url = "plugin://%s/?action=download&title_id=%s&subtitle_id=%s" % (
            __scriptid__, it["series_id"], it["subtitle_id"])
        list_items.append((url, subtitle_row, False,))
        # xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=False)

    list_items = sorted(list_items,
                        reverse=True,
                        key=lambda i: rate_subtitle(i[1].getLabel2(), item["file_original_name"]))
    xbmcplugin.addDirectoryItems(int(sys.argv[1]), list_items)
    return None
