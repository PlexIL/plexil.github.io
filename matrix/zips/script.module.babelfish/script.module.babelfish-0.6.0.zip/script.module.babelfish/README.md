# script.module.babelfish
Python babelfish library packed for Kodi.
