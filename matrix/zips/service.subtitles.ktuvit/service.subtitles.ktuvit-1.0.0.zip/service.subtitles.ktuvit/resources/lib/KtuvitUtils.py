# -*- coding: utf-8 -*-
import re
import os
import unicodedata
import uuid

import requests
from requests import Session
from requests.cookies import RequestsCookieJar
import json
import logging
from bs4 import BeautifulSoup
from string import hexdigits
from collections import defaultdict
from . import pbkdf2
import web_pdb

from base64 import b64decode, b64encode
from hashlib import sha256
import pyaes
import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
from guessit import guessit

__author__ = "PlexIL"

__addon__ = xbmcaddon.Addon()
__version__ = __addon__.getAddonInfo('version')  # Module version
__scriptname__ = __addon__.getAddonInfo('name')
__language__ = __addon__.getLocalizedString
__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__temp__ = xbmcvfs.translatePath(os.path.join(__profile__, 'temp', ''))


logger = logging.getLogger(__name__)


def normalizeString(str):
    return unicodedata.normalize('NFKD', str)


def log(msg):
    xbmc.log((u"### [%s] - %s" % (__scriptname__, msg)), level=xbmc.LOGDEBUG)


def notify(msg_id):
    xbmcgui.Dialog().notification(__scriptname__, __language__(msg_id))


def rate_subtitle(subtitle_filename, video_filename):

    subtitle_info = guessit(subtitle_filename)
    video_info = guessit(video_filename)

    common_keys = set(subtitle_info.keys()) & set(video_info.keys())
    common_elements = {key: subtitle_info[key] for key in common_keys if subtitle_info[key] == video_info[key]}
    return len(common_elements)


def ReversePuctuation(content):
    def FixOneLine(s):
        special_chars = '.,:;''()-?!+=*&$^%#@~`" /'
        prefix = ''
        suffix = ''

        while len(s) > 0 and s[0] in special_chars:
            prefix += s[0]
            s = s[1:]

        while len(s) > 0 and s[-1] in special_chars:
            suffix += s[-1]
            s = s[:-1]

        if prefix == ' -':
            prefix = '- '
        if suffix == ' -':
            suffix = '- '
        return suffix + s + prefix

    result = ""
    # print("both files opened")
    for line in content.splitlines():
        """
        if len(line) > 2:
            result += FixOneLine(line[:-1]) + line[-1]
        else:
            result += line
        """
        result += FixOneLine(line)
        result += "\n"
    return result


class Ktuvit:
    URL_SERVER = 'https://www.ktuvit.me/'

    URI_LOGIN = 'Login.aspx'
    URI_LOGIN_POST = 'Services/MembershipService.svc/Login'
    URI_SEARCH_TITLE = 'Services/ContentProvider.svc/GetSearchForecast'
    URI_SEARCH_SERIES_SUBTITLE = 'Services/GetModuleAjax.ashx'
    URI_SEARCH_MOVIE_SUBTITLE = "MovieInfo.aspx"
    URI_REQ_SUBTITLE_ID = "Services/ContentProvider.svc/RequestSubtitleDownload"
    URI_DOWNLOAD_SUBTITLE = "Services/DownloadFile.ashx"

    def __init__(self, username, password):
        log("Ktuvit initialize1")

        self.username = username
        self.password = password
        self.encrypted_password = None
        self.salt = None
        self.session = Session()
        self.session.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' \
                                             'AppleWebKit/537.36 (KHTML, like Gecko) ' \
                                             'Chrome/77.0.3865.90 Safari/537.36'

    def encrypt_password(self):
        log("password: {}".format(self.password))
        encrypted_password = KtuvitEncryptor(self.username, self.password, self.session).encrypt()
        if not encrypted_password:
            log("Could not encrypt password")
            return False
        self.encrypted_password = encrypted_password
        return True

    def login(self, notify_success=False):
        if not self.encrypt_password():
            return False
        data = {
            "request": {
                "Email": self.username,
                "Password": self.encrypted_password
            }
        }
        log(f"Trying to log in using: {json.dumps(data)}")
        r = self.session.post(self.URL_SERVER + self.URI_LOGIN_POST, json=data)
        if not r.ok:
            log("Bad HTTP code during login")
            notify(32005)
            return False
        r_result = r.json()
        login_results = {}
        if 'd' in r_result:
            try:
                login_results = json.loads(r_result['d'])
            except ValueError:
                log("Could not process JSON from login response")
                notify(32005)
                return False

        if 'IsSuccess' not in login_results:
            log("Login response is different than expected")
            notify(32005)
            return False

        if not login_results['IsSuccess']:
            log("Wrong username or password!")
            notify(32005)
            return False

        if not r.cookies or type(r.cookies) is not RequestsCookieJar:
            log("Could not get the cookie response of the login")
            notify(32005)
            return False

        if 'Login' not in r.cookies.keys():
            log("Could not found login cookie!")
            notify(32005)
            return False

        log("Connected successfully to Ktuvit!")
        if notify_success:
            notify(32014)
        return True

    def terminate(self):
        log("Ktuvit terminate")
        self.session.close()

    def _search_series(self, title):
        log("Searching '{}'".format(title))
        title_request = {
            "request": {
                "SearchString": title,
                "SearchType": "Film"
            }
        }
        r = self.session.post(self.URL_SERVER + self.URI_SEARCH_TITLE, json=title_request, allow_redirects=False,
                              timeout=10)
        if not r.ok:
            return []
        series_found = r.json()
        if 'd' in series_found:
            try:
                series_found = json.loads(series_found['d'])
            except ValueError:
                series_found = None
        if 'Items' in series_found:
            return series_found['Items']
        return []

    def _search_subtitles(self, title_id, season=None, episode=None):
        if season and episode:
            params = {
                'moduleName': 'SubtitlesList',
                'SeriesID': title_id,
                'Season': season,
                'Episode': episode
            }
            r = self.session.get(url=self.URL_SERVER + self.URI_SEARCH_SERIES_SUBTITLE, params=params)
        else:
            params = {
                'ID': title_id,
            }
            r = self.session.get(url=self.URL_SERVER + self.URI_SEARCH_MOVIE_SUBTITLE, params=params)

        if not r.ok:
            return []
        results = r.content
        if not results:
            return []
        subtitles = BeautifulSoup(results, 'html.parser').select('a.fa')
        log("[BS4] Elements found:\n{}".format(subtitles))
        subtitle_list = []
        for i in subtitles:
            subtitle_id = i.attrs['data-subtitle-id']
            release = i.findParent().findParent().text.strip().split('\n')[0]
            subtitle_list.append((subtitle_id, release))

        return subtitle_list  # [(Subtitle ID, name), (....)]

    def _req_download_identifier(self, title_id, subtitle_id):
        log("Request subtitle identifier for: title id: {}, subtitle id: {}".format(title_id, subtitle_id))
        data = {
            'request': {
                'FilmID': title_id,
                'SubtitleID': subtitle_id,
                'FontSize': 0,
                'FontColor': "",
                'PredefinedLayout': -1
            }
        }

        r = self.session.post(self.URL_SERVER + self.URI_REQ_SUBTITLE_ID, json=data, allow_redirects=False,
                              timeout=10)
        r.raise_for_status()
        try:
            r = json.loads(r.json()['d'])
        except ValueError:
            r = {}

        if 'DownloadIdentifier' not in r:
            log("Download Identifier not found")
            return None
        return r['DownloadIdentifier']

    def _download_subtitles(self, download_id, fix_rtl=True):
        log("Downloading subtitles by download identifier - {}".format(download_id))
        data = {'DownloadIdentifier': download_id}
        r = self.session.get(self.URL_SERVER + self.URI_DOWNLOAD_SUBTITLE, params=data,
                             timeout=10)
        if not r.ok:
            return None

        content = r.content
        if not content:
            log("Download subtitle failed")
            return None

        filename = "%s.%s" % (str(uuid.uuid4()), "srt")
        cd = r.headers.get('content-disposition')
        if cd:
            filename = re.findall("filename=(.+)", cd)[0]

        filename = os.path.join(__temp__, filename)

        log("Download subtitle success")

        content = content.decode('cp1255')
        if fix_rtl:
            content = ReversePuctuation(content)

        with open(filename, "w", encoding='cp1255') as subFile:
            subFile.write(content)

        return filename

    def query(self, item):
        if not self.login():
            return False

        subtitles = []
        titles = self._search_series(item['tvshow'])
        if not titles:
            return []

        season = item['season']
        episode = item['episode']
        year = item['year']

        if season and episode:
            log("Searching for:\nTitle: {}\nSeason: {}\nEpisode: {}\nYear: {}".format(
                item['tvshow'], season, episode, year))
        else:
            log("Searching for:\nTitle: {}\nYear: {}\n".format(item['tvshow'], year))

        for candidate in titles:
            title_id = candidate['ID']
            if season and episode:
                result = self._search_subtitles(title_id, season, episode)
            else:
                result = self._search_subtitles(title_id)

            if not result:
                continue

            for subtitle_id, release in result:
                subtitles.append({
                    "series_id": title_id,
                    "subtitle_id": subtitle_id,
                    "title": candidate['EngName'],
                    "season": season,
                    "episode": episode,
                    "release": release,
                    "year": year,
                    "language": "he"
                })

        if subtitles:
            log("Found Subtitle Candidates: {}".format(subtitles))
        return subtitles

    def download_subtitle(self, title_id, subtitle_id, fix_rtl=True):
        log(f"Downloading subtitle from Ktuvit: {subtitle_id}")
        download_id = self._req_download_identifier(title_id, subtitle_id)
        if not download_id:
            log('Unable to retrieve download identifier')
            return None

        content = self._download_subtitles(download_id, fix_rtl)
        if not content:
            log('Unable to download subtitle')
            return None
        return content


class KtuvitEncryptor:
    def __init__(self, username, password, session=None):
        self.username = username
        self.password = password
        self.salt = None
        self.session = session
        self.get_encryption_salt()

    @staticmethod
    def rshift(val, n):
        return (val % 0x100000000) >> n

    @staticmethod
    def js_parseint(s, rad=10):
        digits = ''
        for c in str(s).strip():
            if c not in hexdigits:
                break
            digits += c

        return int(digits, rad) if digits else 0

    @staticmethod
    def to_signed32(n):
        n = n & 0xffffffff
        return n | (-(n & 0x80000000))

    def stringify(self, words, length):
        sigbytes = int(length / 2) + int((length % 2) > 0)
        hex_chars = list()

        for i in range(0, sigbytes):
            bite = self.rshift(words[self.rshift(i, 2)], (24 - (i % 4) * 8)) & 0xff
            hex_chars.append(format(self.rshift(bite, 4), 'x'))
            hex_chars.append(format(bite & 0x0f, 'x'))
        return ''.join(hex_chars)

    def cryptojs_hexparse(self, s):
        words = defaultdict(int)
        for i in range(0, len(s), 2):
            tmp1 = (self.js_parseint(s[i:i + 2], 16))
            tmp2 = (24 - (i % 8) * 4)
            tmp3 = self.to_signed32(tmp1 << tmp2)
            words[self.rshift(i, 3)] |= tmp3
        return self.stringify(words, len(s))

    def cryptojs_pad_iv(self, iv):
        padded = str.ljust(self.cryptojs_hexparse(iv), 32, '0')
        return bytes.fromhex(padded)
        # return str.ljust(self.cryptojs_hexparse(iv), 32, '0').decode('hex')

    @staticmethod
    def pbkdf2_encrypt(key, salt):
        a = pbkdf2.PBKDF2(salt, key, 3000)
        return a.read(16)

    @staticmethod
    def pad(m):
        return m + chr(16 - len(m) % 16).encode() * (16 - len(m) % 16)

    def aes_encrypt(self, msg, key, iv):
        if len(iv) != 16:
            log("iv (Len: {}) - {} is not 16 length".format(len(iv), iv))
            return False
        msg = self.pad(msg)

        aes = pyaes.AESModeOfOperationCBC(key, iv=iv[:16])
        return b64encode(aes.encrypt(msg))

    def get_encryption_salt(self):
        p = re.compile(r"var encryptionSalt = '(.*)';")
        if not self.session or not isinstance(self.session, requests.Session):
            r = requests.get(Ktuvit.URL_SERVER + Ktuvit.URI_LOGIN)
            r.headers['User-Agent'] = \
                'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) ' \
                'Chrome/77.0.3865.90 Safari/537.36'
        else:
            r = self.session.get(Ktuvit.URL_SERVER + Ktuvit.URI_LOGIN)
        if not r.ok:
            log("Can't get encryption salt")
            return False

        log("Searching for encryptionSalt...")
        script_list = [i for i in BeautifulSoup(r.content, 'html.parser').select('div#navbar script') if i.contents]
        for item in script_list:
            search_salt = p.search(item.contents[0])
            if search_salt:
                self.salt = search_salt.group(1)
                log(f"Found salt: {self.salt}")
                return True
        log("Could not get encryptionSalt")
        return False

    def encrypt(self):
        if not self.salt:
            log("No salt was instantiated!")
            return False
        msg = self.password.encode('utf-8')
        iv = self.cryptojs_pad_iv(self.username)
        key = self.pbkdf2_encrypt(self.username, self.salt.encode('utf-8'))

        cipher = self.aes_encrypt(msg, key, iv)
        if not cipher:
            return False

        hash_sha256 = sha256(b64decode(cipher))
        encrypted_password = b64encode(hash_sha256.digest()).decode()
        log("Original password: {}".format(self.password))
        log("Encrypted password: {}".format(encrypted_password))
        return encrypted_password

