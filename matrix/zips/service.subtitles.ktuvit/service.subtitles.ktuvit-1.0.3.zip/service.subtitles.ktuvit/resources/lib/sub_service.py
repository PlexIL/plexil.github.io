import xbmc
import time
from resources.lib.utils import *


class SubtitleService(xbmc.Player):
    def __init__(self, *args, **kwargs):
        xbmc.Player.__init__(self)

    def onPlayBackStarted(self) -> None:
        start_time = time.time()
        while not self.isPlayingVideo():
            log(f"self.isPlayingVideo() - {self.isPlayingVideo()}")
            current_time = time.time()
            if current_time - start_time >= 20:
                break
            xbmc.sleep(1000)

        if 'heb' in self.getAvailableSubtitleStreams():
            xbmcgui.Dialog().notification(
                "Subtitles Present",
                "Hebrew subtitles already present",
                xbmcgui.NOTIFICATION_INFO,
                5000)
            return None

        # Get the filename of the currently playing video
        player = xbmc.Player()
        filename = player.getPlayingFile()

        item = {
            'year': xbmc.getInfoLabel("VideoPlayer.Year"),
            'season': str(xbmc.getInfoLabel("VideoPlayer.Season")),
            'episode': str(xbmc.getInfoLabel("VideoPlayer.Episode")),
            'tvshow': normalizeString(xbmc.getInfoLabel("VideoPlayer.TVshowtitle")),
            'title': normalizeString(xbmc.getInfoLabel("VideoPlayer.OriginalTitle"))
        }
        log(item)

        if item['title'] == "":
            item['title'] = normalizeString(xbmc.getInfoLabel("VideoPlayer.Title"))

        clean_title(item)
        parse_rls_title(item)
        log("Searching for subtitles")
        subtitles_list = helper.query(item)
        if not subtitles_list:
            return None

        log("Found subtitles")
        highest_rating = max(
            subtitles_list,
            key=lambda i: rate_subtitle(i[1].getLabel2(), item["file_original_name"]))

        log(f"highest rating: {highest_rating.get('subtitle_id')}")

        # Download the best subtitle for the video
        rtl = True if __addon__.getSetting('rtl') == "true" else False
        subtitle_file = helper.download_subtitle(highest_rating.get("series_id"), highest_rating.get("subtitle_id"), rtl)
        xbmcgui.Dialog().notification(
            "Downloaded",
            "Downloaded subtitles!",
            xbmcgui.NOTIFICATION_INFO,
            5000)

        log(f"setting subtitles: {subtitle_file}")
        # Set the subtitle in the Kodi player
        player.setSubtitles(subtitle_file)