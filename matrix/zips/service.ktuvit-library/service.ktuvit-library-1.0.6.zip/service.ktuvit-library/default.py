#!/usr/bin/python
import os
import time

import requests
import xbmcgui
import xbmcplugin
from bs4 import BeautifulSoup
from requests import Session
import re
import string
from datetime import datetime
import shutil

import xbmc
import xbmcvfs
import xbmcaddon

__addon__ = xbmcaddon.Addon()
__scriptid__ = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__version__ = __addon__.getAddonInfo('version')  # Module version
__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__temp__ = xbmcvfs.translatePath(os.path.join(__profile__, 'temp', ''))
__kodi_temp__ = xbmcvfs.translatePath("special://temp")


# TMDB globals
TMDB_API = "https://api.themoviedb.org/3/search/"
TMDB_SEARCH_MOVIE = TMDB_API + "movie?api_key=8cf43ad9c085135b9479ad5cf6bbcbda&query={}&year={}page=1"
TMDB_SEARCH_MOVIE = TMDB_API + "multi?api_key=8cf43ad9c085135b9479ad5cf6bbcbda&query={}&page=1"

# String Regex patterns
inside_parenthesis = re.compile(r"\((.*)\)", re.UNICODE)
punctutaion = re.compile(f"[{string.punctuation}]")

STRM_DIRECTORY = os.path.join(__kodi_temp__, "strm_directory")
STRM_PATTERN = r"plugin://plugin.video.elementum/library/movie/play/{}"
ITEMS_FOUND_IN_LIBRARY_THRESHOLD = 4


def log(msg):
    xbmc.log((u"### [%s] - %s" % (__scriptname__, msg)), level=xbmc.LOGDEBUG)


def setup_librarywatchdog():
    librarywatchdog_addon = xbmcaddon.Addon('service.librarywatchdog')
    for i in ["clean", "cleanonstart", "scanonstart"]:
        if not librarywatchdog_addon.getSettingBool(i):
            log(f"Update librarywatchdog setting \"{i}\" = True")
            librarywatchdog_addon.setSettingBool(i, True)


def get_year_by_selector(x):
    year = x.find_next('div', {"class": ['col-md-2', 'subtitleListLeft']}).select('small')[0].text[11:]
    if year:
        return int(year)
    return 0


def filenameify(filename):
    filename = punctutaion.sub("", filename)
    remove_punctuation_map = dict((ord(char), None) for char in r"\/*?:\"<>|")
    return filename.translate(remove_punctuation_map)


def queue_scan(library, path=None):
    path = filenameify(path) if path else ""
    xbmc.executebuiltin(f"UpdateLibrary({library},{path},1)")
    xbmcgui.Dialog().notification(
        "KtuvitLibrary",
        "Library scan triggered",
        xbmcgui.NOTIFICATION_INFO,
        5000)


def get_tmdb_results(query, year):
    if not query:
        return None
    try:
        search_results = requests.get(TMDB_SEARCH_MOVIE.format(query)).json()
    except ValueError:
        return None

    search_results = search_results.get('results')
    if not search_results:
        return None

    results = [x for x in search_results if
                      x.get('title', "").lower() == query.lower() and
                      x.get('media_type') == 'movie' and
                      x.get('release_date') and
                      year-2 < datetime.fromisoformat(x.get('release_date')).year]
    if not results:
        log(f"Query not found: {query}")
        return None
        # results = [x for x in search_results if
        #                   x.get('title', "").lower() == query.lower() and
        #                   x.get('media_type') == 'movie']
        # if not results:
        #     log(f"Query not found: {query}")
        #     return None

    result = results[0]
    return result.get('title'), result.get('id')


def main():
    elements_limit = int(__addon__.getSettingInt('elements_limit'))
    filter_year = int(__addon__.getSettingInt('filter_year'))
    keep_elements_forever = __addon__.getSettingBool('keep_elements_forever')

    num_of_elements = 0
    page = 1
    stop = False

    current_strm_files = os.listdir(STRM_DIRECTORY)
    strm_files = list()
    with Session() as s:
        s.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' \
                                  'AppleWebKit/537.36 (KHTML, like Gecko) ' \
                                  'Chrome/77.0.3865.90 Safari/537.36'
        while not monitor.abortRequested() and not stop:
            # Get latest Ktuvit movies
            try:
                log(f"Requesting page={page}")
                req = s.get(rf"https://ktuvit.me/BrowseFilms.aspx?ResultsPerPage=100&Page={page}")
                if not req.ok:
                    log(f"Could not retrieve request (page={page}): {req.status_code}")
                    break

                data = req.content
            except Exception as e:
                log(f"ERROR: {e}")
                break

            page += 1
            # Parse from html
            selector = BeautifulSoup(data, 'html.parser')
            titles = selector.select("div.col-md-8 div.row:nth-child(1)")

            if not titles:
                log(f"No more titles found. (page={page}")
                break

            # Attempts to write movies that exists in the library
            attempts = 0
            for item in titles:
                if monitor.abortRequested():
                    log("Abort requested - stopping")
                    break
                if num_of_elements >= elements_limit:
                    log(f"num_of_elements >= elements_limit - {num_of_elements} >= {elements_limit}")
                    break
                if attempts == ITEMS_FOUND_IN_LIBRARY_THRESHOLD and keep_elements_forever:
                    log(f"Aborting scraping - {ITEMS_FOUND_IN_LIBRARY_THRESHOLD} items")
                    stop = True
                    break
                title = inside_parenthesis.search(item.text.strip()).group(1)
                year = get_year_by_selector(item)

                if year < filter_year:
                    continue

                num_of_elements += 1

                # Write strm
                filename = "{} - {}.strm".format(filenameify(title), year)
                path = os.path.join(STRM_DIRECTORY, filename)
                # skip existing files
                if os.path.exists(path):
                    log(f"Skipping file: {filename}")
                    attempts += 1
                else:
                    # Get TMDB info by query -> (title, id)
                    results = get_tmdb_results(title, year)
                    if not results:
                        continue

                    found_title, found_id = results
                    # Write to strm file
                    log(f"Adding file: {filename}")
                    with open(path, "w") as f:
                        f.write(STRM_PATTERN.format(found_id))

                strm_files.append(filename)

            if num_of_elements >= elements_limit:
                break

    log(f"Found {num_of_elements} movies!")

    if not keep_elements_forever:
        log("Removing old movies")
        files_to_remove = list(set(current_strm_files) - set(strm_files))
        for strm_file in files_to_remove:
            log(f"Removing file: {strm_file}")
            os.unlink(os.path.join(STRM_DIRECTORY, strm_file))

    if num_of_elements:
        if not xbmc.getCondVisibility('Library.IsScanning'):
            queue_scan('video')


log("KtuvitLibrary initialized")
monitor = xbmc.Monitor()

xbmcgui.Dialog().notification(
        "KtuvitLibrary",
        "Ktuvit Library started",
        xbmcgui.NOTIFICATION_INFO,
        5000)

while not monitor.abortRequested():
    xbmcvfs.mkdirs(STRM_DIRECTORY)
    setup_librarywatchdog()
    log(f"New cycle: {datetime.now().strftime('%m/%d/%Y, %H:%M:%S')}")
    main()
    poll_interval = int(__addon__.getSettingInt('poll_interval'))
    log(f"Sleeping for {poll_interval} hours")
    # xbmc.sleep(poll_interval*60*60*1000)
    monitor.waitForAbort(poll_interval*60*60)

while not monitor.abortRequested():
    monitor.waitForAbort(1)



