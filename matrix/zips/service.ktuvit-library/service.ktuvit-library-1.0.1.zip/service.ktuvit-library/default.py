#!/usr/bin/python
import os
import time

import requests
import xbmcgui
import xbmcplugin
from bs4 import BeautifulSoup
from requests import Session
import re
import string
from datetime import datetime

import xbmc
import xbmcvfs
import xbmcaddon

__addon__ = xbmcaddon.Addon()
__scriptid__ = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__version__ = __addon__.getAddonInfo('version')  # Module version
__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__temp__ = xbmcvfs.translatePath(os.path.join(__profile__, 'temp', ''))

strm_directory = os.path.join(__temp__, "strm_directory")

TMDB_API = "https://api.themoviedb.org/3/search/"

TMDB_SEARCH_MOVIE = TMDB_API + "movie?api_key=8cf43ad9c085135b9479ad5cf6bbcbda&query={}&year={}page=1"
TMDB_SEARCH_MOVIE = TMDB_API + "multi?api_key=8cf43ad9c085135b9479ad5cf6bbcbda&query={}&page=1"
inside_parenthesis = re.compile(r"\((.*)\)", re.UNICODE)
punctutaion = re.compile(f"[{string.punctuation}]")

STRM_PATTERN = r"plugin://plugin.video.elementum/library/movie/play/{}"


def log(msg):
    xbmc.log((u"### [%s] - %s" % (__scriptname__, msg)), level=xbmc.LOGDEBUG)


def get_year_by_selector(x):
    year = x.find_next('div', {"class": ['col-md-2', 'subtitleListLeft']}).select('small')[0].text[11:]
    if year:
        return int(year)
    return 0


def filenameify(filename):
    filename = punctutaion.sub("", filename)
    remove_punctuation_map = dict((ord(char), None) for char in r"\/*?:\"<>|")
    return filename.translate(remove_punctuation_map)


def get_tmdb_results(query, year):
    if not query:
        return None
    try:
        search_results = requests.get(TMDB_SEARCH_MOVIE.format(query)).json()
    except ValueError:
        return None

    search_results = search_results.get('results')
    if not search_results:
        return None

    results = [x for x in search_results if
                      x.get('title', "").lower() == query.lower() and
                      x.get('media_type') == 'movie' and
                      str(year) in x.get('release_date')]
    if not results:
        results = [x for x in search_results if
                          x.get('title', "").lower() == query.lower() and
                          x.get('media_type') == 'movie']
        if not results:
            print(f"Query not found: {query}")
            return None

    result = results[0]
    log(result.get('release_date'))
    return result.get('title'), result.get('id')


def main():
    elements_limit = int(__addon__.getSettingInt('elements_limit'))
    filter_year = int(__addon__.getSettingInt('filter_year'))

    num_of_elements = 0
    page = 1
    # Remove all strm files
    xbmcvfs.rmdir(strm_directory, force=True)
    xbmcvfs.mkdirs(strm_directory)

    while True:
        # Get latest Ktuvit movies
        try:
            with Session() as s:
                s.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' \
                                                     'AppleWebKit/537.36 (KHTML, like Gecko) ' \
                                                     'Chrome/77.0.3865.90 Safari/537.36'
                log(rf"Retrieving from: https://ktuvit.me/BrowseFilms.aspx?ResultsPerPage=100&Page={page}")
                req = s.get(rf"https://ktuvit.me/BrowseFilms.aspx?ResultsPerPage=100&Page={page}")
                data = req.content
        except Exception as e:
            log(f"ERROR: {e}")
            break

        page += 1
        # Parse from html
        selector = BeautifulSoup(data, 'html.parser')
        titles = selector.select("div.col-md-8 div.row:nth-child(1)")

        for item in titles:
            if num_of_elements >= elements_limit:
                break
            log(num_of_elements)
            title = inside_parenthesis.search(item.text.strip()).group(1)
            year = get_year_by_selector(item)

            if year < filter_year:
                continue

            # Get TMDB id by title
            results = get_tmdb_results(title, year)
            if not results:
                # print("-------------\n\n")
                continue

            num_of_elements += 1

            # Extract found results
            # print(results)
            found_title, found_id = results

            # Write to strm file
            # print(STRM_PATTERN.format(found_id))

            filename = "{} - {}.strm".format(filenameify(found_title), year)
            path = os.path.join(strm_directory, filename)
            log(f"Adding file: {filename}")
            with open(path, "w") as f:
                f.write(STRM_PATTERN.format(found_id))
            # print(path)
            # print("-------------\n\n")

        if num_of_elements >= elements_limit:
            break
    log(f"Found {num_of_elements} movies!")


log("KtuvitLibrary initialized")
monitor = xbmc.Monitor()

xbmcgui.Dialog().notification(
        "KtuvitLibrary",
        "Ktuvit Library started",
        xbmcgui.NOTIFICATION_INFO,
        5000)

while True:
    log(f"New cycle: {datetime.now().strftime('%m/%d/%Y, %H:%M:%S')}")
    main()
    poll_interval = int(__addon__.getSettingInt('poll_interval'))
    log(f"Sleeping for {poll_interval} hours")
    xbmc.sleep(poll_interval*60*60*1000)
    while not monitor.abortRequested():
        monitor.waitForAbort(1)



