#!/usr/bin/python
import os
import requests
import xbmcgui
from bs4 import BeautifulSoup
from requests import Session
import re
import string
from datetime import datetime
import unicodedata

import xbmc
import xbmcvfs
import xbmcaddon

__addon__ = xbmcaddon.Addon()
__scriptid__ = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')
__version__ = __addon__.getAddonInfo('version')  # Module version
__profile__ = xbmcvfs.translatePath(__addon__.getAddonInfo('profile'))
__temp__ = xbmcvfs.translatePath(os.path.join(__profile__, 'temp', ''))
__kodi_temp__ = xbmcvfs.translatePath("special://temp")


# TMDB globals
TMDB_API = "https://api.themoviedb.org/3/search/"
TMDB_SEARCH_MOVIE = TMDB_API + "multi?api_key=8cf43ad9c085135b9479ad5cf6bbcbda&query={}&page=1"

SESSION_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' \
				'AppleWebKit/537.36 (KHTML, like Gecko) ' \
				'Chrome/77.0.3865.90 Safari/537.36'

# String Regex patterns
inside_parenthesis = re.compile(r"\((.*)\)", re.UNICODE)
punctutaion = re.compile(f"[{string.punctuation}]")
alphanumeric_pattern = re.compile(f"[A-Za-z0-9 ]")

STRM_DIRECTORY = os.path.join(__kodi_temp__, "strm_directory")
STRM_PATTERN = r"plugin://plugin.video.elementum/library/movie/play/{}"
ITEMS_FOUND_IN_LIBRARY_THRESHOLD = 4


def log(msg):
	xbmc.log((u"### [%s] - %s" % (__scriptname__, msg)), level=xbmc.LOGDEBUG)


def notify(msg, debug_level=xbmcgui.NOTIFICATION_INFO, display_time=5000):
	xbmcgui.Dialog().notification(
		"KtuvitLibrary",
		msg,
		debug_level,
		display_time)


def _kodi_scan_library(library, path=None):
	path = filenameify(path) if path else ""
	xbmc.executebuiltin(f"UpdateLibrary({library},{path},1)")


def setup_librarywatchdog():
	librarywatchdog_addon = xbmcaddon.Addon('service.librarywatchdog')
	for i in ["clean", "cleanonstart", "scanonstart"]:
		if not librarywatchdog_addon.getSettingBool(i):
			log(f"Update librarywatchdog setting \"{i}\" = True")
			librarywatchdog_addon.setSettingBool(i, True)


def filenameify(filename):
	def strip_accents(s):
		return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn')

	filename = strip_accents(filename)
	filename = punctutaion.sub("", filename)
	remove_punctuation_map = dict((ord(char), None) for char in r"\/*?:\"<>|")
	filename = filename.translate(remove_punctuation_map)
	filename = ''.join([x for x in filename if alphanumeric_pattern.match(x)])
	return filename.replace("  ", " ")


class KtuvitLibrary(xbmc.Monitor):
	def __init__(self):
		xbmc.Monitor.__init__(self)
		log("Ktuvit Library initialized")
		notify("Ktuvit Library initialized")

		self.limit = int(__addon__.getSettingInt('elements_limit'))
		self.filter_year = int(__addon__.getSettingInt('filter_year'))
		self.keep_elements_forever = __addon__.getSettingBool('keep_elements_forever')
		self.poll_interval = int(__addon__.getSettingInt('poll_interval'))
		log(
			f"limit={self.limit} filter_year={self.filter_year} "
			f"keep={self.keep_elements_forever} poll_interval={self.poll_interval}")

		self.update_in_progress = False
		self.scan_started = False

		while not self.abortRequested():
			xbmcvfs.mkdirs(STRM_DIRECTORY)
			setup_librarywatchdog()
			log(f"New cycle: {datetime.now().strftime('%m/%d/%Y, %H:%M:%S')}")
			self.run()
			log(f"Sleeping for {self.poll_interval} hours")
			self.waitForAbort(self.poll_interval * 60 * 60)

		while not self.abortRequested():
			self.waitForAbort(1)

	def onScanStarted(self, library: str) -> None:
		log("scan started")
		self.update_in_progress = True

	def onScanFinished(self, library: str) -> None:
		log("scan finished")
		self.update_in_progress = False
		if self.scan_started:
			notify("Update library ended")
			self.scan_started = False

	def onSettingsChanged(self) -> None:
		log("Settings changed")
		self.limit = int(__addon__.getSettingInt('elements_limit'))
		self.filter_year = int(__addon__.getSettingInt('filter_year'))
		self.keep_elements_forever = __addon__.getSettingBool('keep_elements_forever')
		self.poll_interval = int(__addon__.getSettingInt('poll_interval'))
		log(
			f"limit={self.limit} filter_year={self.filter_year} "
			f"keep={self.keep_elements_forever} poll_interval={self.poll_interval}")

	def run(self):
		current_strm_files = os.listdir(STRM_DIRECTORY)
		strm_files = self.get_ktuvit_movies()

		if not self.keep_elements_forever:
			log("Removing old movies")
			files_to_remove = list(set(current_strm_files) - set(strm_files))
			for strm_file in files_to_remove:
				log(f"Removing file: {strm_file}")
				os.unlink(os.path.join(STRM_DIRECTORY, strm_file))

		if strm_files:
			self.scan_library()

	@staticmethod
	def get_year_by_selector(x):
		year = x.find_next('div', {"class": ['col-md-2', 'subtitleListLeft']}).select('small')[0].text[11:]
		if year:
			return int(year)
		return 0

	@staticmethod
	def tmdb_best_matched_movie(filtered_results, query, year):
		top_score = 0
		top_result = None

		filtered_results = [
			x for x in filtered_results if
			x.get('media_type') == 'movie' and
			x.get('release_date') and
			year - 1 < datetime.fromisoformat(x.get('release_date')).year]

		query_title = filenameify(query.lower())
		query_words = query_title.split(' ')

		for x in filtered_results:
			result_title = filenameify(x.get('title', "").lower())
			result_title_words = result_title.split(' ')

			# Jaccard dissimiliarity calculation
			common_words = len(set(result_title_words) & set(query_words))
			union_words = len(set(result_title_words) | set(query_words))
			score = (common_words / union_words)

			if score > top_score:
				top_score = score
				top_result = x
		if top_result:
			log(f"[Score: {top_score}] - Query: {query_title} - Top result: {top_result.get('title')}")
		else:
			log(f"Query not found: {query_title}")
		return top_result

	def tmdb_movie_query(self, query, year):
		"""
		Searches a movie in TMDB
		@param query: title of Movie / Show
		@param year: year of release
		@return: (Title, Movie ID)
		"""
		if not query:
			return None
		try:
			search_results = requests.get(TMDB_SEARCH_MOVIE.format(query)).json()
		except ValueError:
			return None

		search_results = search_results.get('results', None)
		if not search_results:
			return None

		movie = self.tmdb_best_matched_movie(search_results, query, year)

		if not movie:
			return None

		return movie.get('title'), movie.get('id')

	@staticmethod
	def get_ktuvit_movies_from_page(page):
		"""
		Get movies from ktuvit by page
		@param page: page number
		@return: list of movies as bs4 selectors
		"""
		try:
			with Session() as s:
				s.headers['User-Agent'] = SESSION_UA

				log(f"Requesting page={page}")
				req = s.get(rf"https://ktuvit.me/BrowseFilms.aspx?ResultsPerPage=100&Page={page}")
				if not req.ok:
					log(f"Could not retrieve request (page={page}): {req.status_code}")
					return None

				data = req.content
		except Exception as e:
			log(f"ERROR: {e}")
			return None

		# Parse movie titles from html
		selector = BeautifulSoup(data, 'html.parser')
		titles = selector.select("div.col-md-8 div.row:nth-child(1)")
		if not titles:
			log(f"No more titles found. (page={page}")
			return None
		return titles

	def get_ktuvit_movies(self):
		"""
		Creates movie library based on ktuvit, returns strm list
		@return: list of strm files
		"""
		strm_files = list()
		total_movies = 0
		num_not_found = 0
		page = 1
		stop = False

		while not self.abortRequested() and not stop:
			# Get latest Ktuvit movies
			titles = self.get_ktuvit_movies_from_page(page)
			if not titles:
				break
			page += 1

			# Attempts to write movies that exists in the library
			attempts = 0

			# Main Loop - Iterates found titles
			for item in titles:
				if self.abortRequested():
					log("Abort requested - stopping")
					stop = True
				if total_movies >= self.limit:
					stop = True
					break
				if attempts == ITEMS_FOUND_IN_LIBRARY_THRESHOLD and self.keep_elements_forever:
					log(f"Aborting scraping - {ITEMS_FOUND_IN_LIBRARY_THRESHOLD} items")
					stop = True
					break

				# Parse title and year
				title = inside_parenthesis.search(item.text.strip()).group(1)
				year = self.get_year_by_selector(item)

				# Filters current title if release year criteria is not met
				if year < self.filter_year:
					continue

				# Prepare strm file
				filename = "{} - {}.strm".format(filenameify(title), year)
				path = os.path.join(STRM_DIRECTORY, filename)

				# Skip if strm file already exists
				if os.path.exists(path):
					log(f"Skipping file: {filename}")
					attempts += 1
				else:
					# Query movie in TMDB
					results = self.tmdb_movie_query(title, year)
					if not results:
						num_not_found += 1
						continue

					found_title, found_id = results
					# Write to strm file
					log(f"Adding file: {filename}")
					with open(path, "w") as f:
						f.write(STRM_PATTERN.format(found_id))
				total_movies += 1
				strm_files.append(filename)

		log(f"Found {len(strm_files)} movies!, {num_not_found} movies not found")
		notify(f"Found {len(strm_files)} movies!, {num_not_found} movies not found")
		return strm_files

	def scan_library(self):
		self.scan_started = True
		if self.update_in_progress:
			notify("Library update already in progress, Skipping")
			return
		notify("Update library started")
		_kodi_scan_library('video')


KtuvitLibrary()
