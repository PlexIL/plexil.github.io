import os
import string

import requests
from bs4 import BeautifulSoup
from requests import Session
import re

TMDB_API = "https://api.themoviedb.org/3/search/"
TMDB_SEARCH_MOVIE = TMDB_API + "movie?api_key=8cf43ad9c085135b9479ad5cf6bbcbda&query={}&year={}page=1"
TMDB_SEARCH_MOVIE = TMDB_API + "multi?api_key=8cf43ad9c085135b9479ad5cf6bbcbda&query={}&page=1"

inside_parenthesis = re.compile(r"\((.*)\)", re.UNICODE)
punctutaion = re.compile(f"[{string.punctuation}]")
STRM_PATTERN = r"plugin://plugin.video.elementum/library/movie/play/{}"


def get_year_by_selector(x):
    return x.find_next('div', {"class": ['col-md-2', 'subtitleListLeft']}).select('small')[0].text[11:]


def filenameify(filename):
    filename = punctutaion.sub("", filename)
    remove_punctuation_map = dict((ord(char), None) for char in r"\/*?:\"<>|")
    return filename.translate(remove_punctuation_map)


def get_tmdb_results(query, year):
    if not query:
        print("NONEE")
        return None
    try:
        search_results = requests.get(TMDB_SEARCH_MOVIE.format(query)).json()
    except ValueError:
        return None

    search_results = search_results.get('results')
    if not search_results:
        return None

    results = [x for x in search_results if
                      x.get('title', "").lower().replace("'", "") == query.lower().replace("'", "") and
                      x.get('media_type') == 'movie' and
                      year in x.get('release_date')]
    if not results:
        results = [x for x in search_results if
                          x.get('title', "").lower() == query.lower() and
                          x.get('media_type') == 'movie']
        if not results:
            print(f"Query not found: {query}")
            return None

    result = results[0]
    print(result.get('release_date'))
    return result.get('title'), result.get('id')


def main():
    # Get latest Ktuvit movies
    with Session() as s:
        s.headers['User-Agent'] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' \
                                             'AppleWebKit/537.36 (KHTML, like Gecko) ' \
                                             'Chrome/77.0.3865.90 Safari/537.36'
        req = s.get(r"https://ktuvit.me/BrowseFilms.aspx?ResultsPerPage=100&Page=1")
        data = req.content

    # Parse from html
    selector = BeautifulSoup(data, 'html.parser')
    titles = selector.select("div.col-md-8 div.row:nth-child(1)")

    for item in titles:
        title = inside_parenthesis.search(item.text.strip()).group(1)
        year = get_year_by_selector(item)
        # print(title, year)

        # Get TMDB id by title
        results = get_tmdb_results(title, year)
        if not results:
            print("-------------\n\n")
            continue

        # Extract found results
        print(results)
        found_title, found_id = results

        # Write to strm file
        print(STRM_PATTERN.format(found_id))
        os.makedirs("strm_directory", exist_ok=True)

        print(found_title)
        with open("strm_directory\\{} - {}.strm".format(filenameify(found_title), year), "w") as f:
            f.write(STRM_PATTERN.format(found_id))

        print("-------------\n\n")


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    main()

